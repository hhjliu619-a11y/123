#!/usr/bin/env python3
"""Reproduce revised Figure 4 from the source-reported values.

The source figure's four numerical estimates and confidence intervals are
unchanged. The unverified 'week 52' designation is removed from the general
adverse-event row; the manuscript caption explains protocol reporting windows.
"""

from pathlib import Path
import csv

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager


OUTPUT_DIR = Path(__file__).resolve().parent
ROWS = [
    ("Adjudicated CMV disease: week 52", -1.4, -6.5, 3.8),
    ("Adjudicated CMV disease: week 28", -1.7, -3.4, 0.1),
    ("Any adverse event (source analysis)", -0.1, -4.4, 4.2),
    ("Drug-related serious AE: week 52", -3.7, -7.0, -0.9),
]


def main():
    available_fonts = {font.name for font in font_manager.fontManager.ttflist}
    chosen_font = "Arial" if "Arial" in available_fonts else "DejaVu Sans"
    plt.rcParams.update({
        "font.family": chosen_font,
        "font.size": 14,
        "axes.unicode_minus": True,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })

    # Exact raster output: 3157 x 1400 px. PDF retains vector primitives.
    fig = plt.figure(figsize=(15.785, 7), dpi=200, facecolor="white")
    label_ax = fig.add_axes([0.015, 0.205, 0.310, 0.650])
    forest_ax = fig.add_axes([0.344, 0.205, 0.443, 0.650])
    value_ax = fig.add_axes([0.803, 0.205, 0.187, 0.650])

    teal = "#2A7380"
    ink = "#252F35"
    gray = "#89969E"
    for ax in (label_ax, forest_ax, value_ax):
        ax.set_ylim(-0.5, 3.5)
    for ax in (label_ax, value_ax):
        ax.set_xlim(0, 1)
        ax.set_axis_off()

    fig.text(
        0.5, 0.952,
        "Source-reported treatment differences and 95% confidence intervals",
        ha="center", va="top", fontsize=18.1, color=ink,
    )
    label_ax.text(0, 3.71, "Outcome", fontsize=12.5, fontweight="bold",
                  ha="left", va="bottom", color=ink, clip_on=False)
    value_ax.text(0.02, 3.71, "Difference (95% CI)", fontsize=12.5,
                  fontweight="bold", ha="left", va="bottom", color=ink,
                  clip_on=False)

    for index, (label, estimate, lower, upper) in enumerate(ROWS):
        y = 3 - index
        label_ax.text(1, y, label, fontsize=14.2, color=ink,
                      ha="right", va="center", clip_on=False)
        forest_ax.errorbar(
            estimate, y,
            xerr=[[estimate - lower], [upper - estimate]],
            fmt="o", color=teal, ecolor=teal,
            markersize=8, elinewidth=2.0,
            capsize=5, capthick=1.6, zorder=3,
        )
        value_ax.text(0.02, y, f"{estimate:.1f} ({lower:.1f}, {upper:+.1f})",
                      fontsize=14.2, color=ink, ha="left", va="center",
                      clip_on=False)

    forest_ax.axvline(0, color=gray, linestyle=(0, (4, 4)), linewidth=1.5,
                      zorder=1)
    forest_ax.set_xlim(-7.6, 4.8)
    forest_ax.set_xticks([-6, -4, -2, 0, 2, 4])
    forest_ax.set_yticks([])
    forest_ax.tick_params(axis="x", colors=ink, labelsize=13,
                          length=4, width=1)
    forest_ax.spines[["left", "right", "top"]].set_visible(False)
    forest_ax.spines["bottom"].set_color(gray)
    forest_ax.set_xlabel(
        "Reported treatment difference per 100 participants\n"
        "(letermovir minus valganciclovir)",
        fontsize=14.3, color=ink, labelpad=12,
    )

    fig.savefig(OUTPUT_DIR / "figure4_revised.jpg", dpi=200,
                facecolor="white", pil_kwargs={"quality": 98})
    fig.savefig(OUTPUT_DIR / "figure4_revised.pdf", facecolor="white")
    plt.close(fig)

    with (OUTPUT_DIR / "figure4_data.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["outcome", "treatment_difference_per_100", "ci95_lower", "ci95_upper"])
        writer.writerows(ROWS)
    print(f"Wrote Figure 4 JPEG, PDF, and CSV in {OUTPUT_DIR}; font={chosen_font}")


if __name__ == "__main__":
    main()
