来特莫韦肾移植论文修订交付

Letermovir_Manuscript_Revised.docx：可编辑的完整英文修订稿。
Letermovir_Manuscript_Revised.pdf：同一最终稿的18页PDF，供阅读与版面核对。
Letermovir_Revision_Notes.docx / .pdf：3页中文修改说明、数值保护记录及作者待核事项。
QA_Status.txt：最终验收范围及未核验事项。
figure4_revised.jpg / .pdf：Figure 4修订图；四组数值不变，一般AE不再统一标为week 52。
figure4_data.csv：原稿中已给出的四组图示效应值与95%置信区间。
figure4_redraw.py：Figure 4可复现绘图脚本，需Python及matplotlib（JPEG导出需Pillow）。在同一目录执行将重新生成图4和CSV。

本次使用用户上传的medical-manuscript-integrated Skill修订。原稿保留不变，未套用特定期刊规则，未代填作者、基金或伦理声明。全文参考文献身份及编号保留；没有进行未经验证的文献替换或EndNote域重建。
